"""
بوت واتساب مجاني للعيادة
WhatsApp Cloud API + Gemini API (free tier)

التشغيل:
  pip install -r requirements.txt
  cp .env.example .env   # واملأ القيم، ولا تشارك المفاتيح في الشات
  python app.py

المتغيرات المطلوبة في .env:
  WHATSAPP_TOKEN, WHATSAPP_PHONE_NUMBER_ID, WHATSAPP_VERIFY_TOKEN,
  GEMINI_API_KEY, GEMINI_MODEL=gemini-2.5-flash

لو GEMINI_API_KEY مش موجود، البوت يشتغل بالردود الثابتة فقط
(المواعيد، العنوان، السعر، الحجز) من غير ذكاء اصطناعي.
"""
import json
import os
import re
from datetime import datetime

import requests
from flask import Flask, jsonify, request

app = Flask(__name__)

WHATSAPP_TOKEN = os.environ.get("WHATSAPP_TOKEN", "")
PHONE_NUMBER_ID = os.environ.get("WHATSAPP_PHONE_NUMBER_ID", "")
VERIFY_TOKEN = os.environ.get("WHATSAPP_VERIFY_TOKEN", "clinic-verify-token")
GEMINI_API_KEY = os.environ.get("GEMINI_API_KEY", "")
GEMINI_MODEL = os.environ.get("GEMINI_MODEL", "gemini-2.5-flash")

BASE_DIR = os.path.dirname(os.path.abspath(__file__))
BOOKINGS_FILE = os.path.join(BASE_DIR, "bookings.json")

# --- تحميل بيانات العيادة من clinic_config.json ---
with open(os.path.join(BASE_DIR, "clinic_config.json"), encoding="utf-8") as f:
    CLINIC = json.load(f)

# جلسات الحجز في الذاكرة: {رقم_المريض: {"step": ..., "data": {...}}}
sessions = {}


def load_bookings():
    if not os.path.exists(BOOKINGS_FILE):
        return []
    with open(BOOKINGS_FILE, encoding="utf-8") as f:
        return json.load(f)


def save_booking(booking):
    bookings = load_bookings()
    bookings.append(booking)
    with open(BOOKINGS_FILE, "w", encoding="utf-8") as f:
        json.dump(bookings, f, ensure_ascii=False, indent=2)


def send_whatsapp(to, text):
    """إرسال رسالة عبر WhatsApp Cloud API."""
    if not WHATSAPP_TOKEN or not PHONE_NUMBER_ID:
        print(f"[DRY RUN] To {to}: {text}")
        return False
    url = f"https://graph.facebook.com/v21.0/{PHONE_NUMBER_ID}/messages"
    headers = {
        "Authorization": f"Bearer {WHATSAPP_TOKEN}",
        "Content-Type": "application/json",
    }
    payload = {
        "messaging_product": "whatsapp",
        "to": to,
        "type": "text",
        "text": {"body": text[:4000]},
    }
    r = requests.post(url, headers=headers, json=payload, timeout=30)
    r.raise_for_status()
    return True


def gemini_reply(user_text, history):
    """الرد عبر Gemini. يرجع None لو المفتاح مش موجود أو حصل خطأ/حد مجاني."""
    if not GEMINI_API_KEY:
        return None
    system = (
        f"أنت مساعد واتساب لعيادة {CLINIC['clinic_name']}، تخصص {CLINIC['specialty']}.\n"
        f"العنوان: {CLINIC['address']}\n"
        f"المواعيد: {CLINIC['working_hours']}\n"
        f"سعر الكشف: {CLINIC['consultation_price']}\n"
        f"رقم الحجز المسبق لمحرم بك: {CLINIC.get('booking_phone', '')}\n"
        f"رقم واتساب العيادة: {CLINIC.get('whatsapp_number', '')}\n"
        f"التعليمات: {CLINIC['instructions']}\n"
        "رد بالعربية المصرية باختصار وبلطف. لا تشخّص ولا توصف علاجاً ولا جرعات. "
        "لو سؤال طبي محدد أو حالة طارئة، اطلب من المريض التواصل مع العيادة فوراً أو التوجه للطوارئ، "
        "ولا تجمع بيانات طبية حساسة. لو طلب حجز، اسأل عن الفرع أولاً (البيطاش أو محرم بك)، ثم الاسم والتاريخ والوقت وسبب الزيارة باختصار."
    )
    contents = [{"role": "user", "parts": [{"text": system}]}]
    for role, text in history[-6:]:
        contents.append({"role": role, "parts": [{"text": text}]})
    contents.append({"role": "user", "parts": [{"text": user_text}]})
    url = (
        f"https://generativelanguage.googleapis.com/v1beta/models/"
        f"{GEMINI_MODEL}:generateContent?key={GEMINI_API_KEY}"
    )
    try:
        r = requests.post(url, json={"contents": contents}, timeout=30)
        if r.status_code == 429:
            print("Gemini rate limit (429) - falling back to rules")
            return None
        r.raise_for_status()
        data = r.json()
        return data["candidates"][0]["content"]["parts"][0]["text"].strip()
    except Exception as e:
        print(f"Gemini error: {e}")
        return None


def rule_reply(text, sender):
    """الردود الثابتة المجانية: مواعيد، عنوان، سعر، حجز، تحويل لإنسان."""
    t = text.strip()
    low = t.lower()

    # --- خطوات الحجز ---
    if sender in sessions:
        s = sessions[sender]
        if s["step"] == "branch":
            branch = "محرم بك" if "محرم" in t else "البيطاش" if "بيطاش" in t or "عجمي" in t else t
            s["data"]["branch"] = branch
            s["step"] = "name"
            note = ""
            if branch == "محرم بك":
                note = " ملحوظة: حجز محرم بك مسبقاً قبلها بيوم على رقم 01010754737."
            return "تمام، فرع " + branch + "." + note + " ممكن اسمك بالكامل؟"
        if s["step"] == "name":
            s["data"]["name"] = t
            s["step"] = "date"
            branch = s["data"].get("branch", "")
            if branch == "محرم بك":
                return "تمام يا " + t + "، تحب تحجز يوم الجمعة إمتى؟ اكتب التاريخ، مثال: الجمعة 28 نوفمبر، والحجز مسبقاً قبلها بيوم."
            return "تمام يا " + t + "، تحب تحجز يوم إيه؟ أيام البيطاش: سبت واتنين وأربع، من 3 لـ 5 مساءً. اكتب التاريخ، مثال: السبت 29 نوفمبر"
        if s["step"] == "date":
            s["data"]["date"] = t
            s["step"] = "time"
            return "تمام، الساعة كام تحب؟ مواعيدنا: " + CLINIC["working_hours"]
        if s["step"] == "time":
            s["data"]["time"] = t
            s["step"] = "reason"
            return "آخر سؤال، سبب الزيارة باختصار إيه؟"
        if s["step"] == "reason":
            s["data"]["reason"] = t
            s["data"]["phone"] = sender
            s["data"]["created_at"] = datetime.now().isoformat()
            save_booking(s["data"])
            del sessions[sender]
            return (
                "تم الحجز ✅\n"
                f"الاسم: {s['data']['name']}\n"
                f"الفرع: {s['data'].get('branch', '')}\n"
                f"اليوم: {s['data']['date']} - الساعة: {s['data']['time']}\n"
                f"سبب الزيارة: {s['data']['reason']}\n"
                "هنأكد معاك قبل الموعد. لو عايز تغيّر أو تلغي، ابعت: إلغاء الحجز"
            )

    if any(w in t for w in ["حجز", "احجز", "موعد", "عايز اكشف"]):
        sessions[sender] = {"step": "branch", "data": {}}
        return "أهلاً بيك في عيادة دكتور ضياء الرحمن أحمد، نحجز لك موعد؟ تحب فرع البيطاش ولا فرع محرم بك؟"

    if "إلغاء" in t:
        sessions.pop(sender, None)
        return "تم إلغاء خطوة الحجز الحالية. لو عندك حجز مؤكد وعايز تلغيه، ابعت اسمك وتاريخ الحجز وهنلغي من عندنا."

    if any(w in t for w in ["مواعيد", "مواعيد العمل", "فاتحين", "بتفتحوا"]):
        return f"مواعيد العيادة: {CLINIC['working_hours']}"
    if any(w in t for w in ["عنوان", "مكان", "فين", "لوكيشن"]):
        return f"عنوان العيادة: {CLINIC['address']}"
    if any(w in t for w in ["سعر", "كشف", "تكلفة", "بكام"]):
        return f"سعر الكشف: {CLINIC['consultation_price']}"
    if any(w in t for w in ["دكتور", "إنسان", "موظف", "كلم حد", "طوارئ", "طارئ"]):
        return "تمام، هحوّلك لحد من العيادة يرد عليك. ممكن تكتب سؤالك واسمك ورقمك، وهنرد عليك في أقرب وقت. ولو حالة طارئة، توجه للطوارئ فوراً."

    return None  # لا يوجد رد ثابت مناسب -> جرّب Gemini


@app.route("/", methods=["GET"])
def home():
    return jsonify({"status": "ok", "service": "clinic-whatsapp-bot"})


@app.route("/health", methods=["GET"])
def health():
    return jsonify({
        "status": "ok",
        "whatsapp_configured": bool(WHATSAPP_TOKEN and PHONE_NUMBER_ID),
        "gemini_configured": bool(GEMINI_API_KEY),
        "model": GEMINI_MODEL,
    })


@app.route("/webhook", methods=["GET"])
def verify_webhook():
    # التحقق من Meta عند ربط الـ Webhook
    mode = request.args.get("hub.mode")
    token = request.args.get("hub.verify_token")
    challenge = request.args.get("hub.challenge")
    if mode == "subscribe" and token == VERIFY_TOKEN:
        return challenge, 200
    return "verification failed", 403


@app.route("/webhook", methods=["POST"])
def receive_message():
    data = request.get_json(silent=True) or {}
    try:
        for entry in data.get("entry", []):
            for change in entry.get("changes", []):
                value = change.get("value", {})
                for msg in value.get("messages", []):
                    sender = msg.get("from", "")
                    if msg.get("type") != "text":
                        send_whatsapp(sender, "أهلاً بيك، ابعت رسالة مكتوبة وهنرد عليك.")
                        continue
                    text = msg["text"]["body"]
                    reply = rule_reply(text, sender)
                    if reply is None:
                        reply = gemini_reply(text, [])
                    if reply is None:
                        reply = (
                            "أهلاً بيك في عيادة " + CLINIC["clinic_name"] + ".\n"
                            "تقدر تبعت: حجز، مواعيد، عنوان، سعر الكشف، "
                            "أو ابعت: دكتور، لو عايز تكلم حد من العيادة."
                        )
                    send_whatsapp(sender, reply)
    except Exception as e:
        print(f"webhook error: {e}")
    return jsonify({"status": "received"}), 200


if __name__ == "__main__":
    port = int(os.environ.get("PORT", "5000"))
    app.run(host="0.0.0.0", port=port)
